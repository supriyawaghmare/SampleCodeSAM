package com.wellsfargo.counselor.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Portfolio {

    @Id
    @GeneratedValue()
    private long PortfolioId;
    
    @OneToOne(mappedBy = "Portfolio")
    private Client client;
    

    @Column(nullable = false)
    private Date creationDate;

    protected Portfolio() {

    }

    public Portfolio(Date creationDate) {
        this.creationDate = PcreationDate;
        
    }

    public Long PortfolioId() {
        return portfolioId;
    }

    public Client getClientId() {
        return getClientId;
    }
    
    public void setClientID(Client getClientId) {
        this.getClientId = client;
    }

}
