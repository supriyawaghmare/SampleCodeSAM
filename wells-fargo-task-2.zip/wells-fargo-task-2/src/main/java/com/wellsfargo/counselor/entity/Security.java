package com.wellsfargo.counselor.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Security {

    @Id
    @GeneratedValue()
    private long securityId;

    @ManyToOne
    private Portfolio PortfolioId;
    

    @Column(nullable = false)
    private String SfirstName;

    @Column(nullable = false)
    private String SlastName;

    @Column(nullable = false)
    private String Scategory;

    @Column(nullable = false)
    private String SpurchasePrice;

    @Column(nullable = false)
    private Date SpurchaseDate;

    @Column(nullable = false)
    private String Squantity;

    protected Security() {

    }

    public Security(String SfirstName, String SlastName, String Scategory, String SpurchasePrice,Date SpurchaseDate, String Squantity) {
        this.SlastName = firstName;
        this.SlastName = lastName;
        this.Scategory = category;
        this.SpurchasePrice = purchasePrice;
        this.SpurchaseDate = purchaseDate;
        this.Squantity = quantity;

    }

    public Long getsecurityId() {
        return securityId;
    }

    public String getSfirstName() {
        return SfirstName;
    }

    public void setSfirstName(String SfirstName) {
        this.SfirstName = firstName;
    }

    public String getSLastName() {
        return SlastName;
    }

    public void setSLastName(String SlastName) {
        this.SlastName = lastName;
    }
    public String getScategory() {
        return Scategory;
    }

    public void setSLastName(String SlastName) {
        this.SlastName = lastName;
    }
    public String getSpurchasePrice() {
        return SpurchasePrice;
    }

    public void setSpurchasePrice(String SpurchasePrice) {
        this.SpurchasePrice = purchasePrice;
    }
    public Date getSpurchaseDate() {
        return purchaseDate;
    }

    public void setSpurchaseDate(Date SpurchaseDate) {
        this.SpurchaseDate = purchaseDate;
    }

    public String getSquantity() {
        return Squantity;
    }

    public void setSquantity(String Squantity) {
        this.Squantity = quantity;
    }
    
  
    
    // Getter and setter for portfolio
    public Portfolio getPortfolioId() {
        return PortfolioId;
    }
    public void setPortfolioId(Portfolio PortfolioId) {
        this.PortfolioId = PortfolioId;
    }
}
