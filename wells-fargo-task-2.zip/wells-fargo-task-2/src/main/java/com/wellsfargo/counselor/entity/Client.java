package com.wellsfargo.counselor.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Client {

    @Id
    @GeneratedValue()
    private long clientId;

    @Column(nullable = false)
    private String CfirstName;

    @Column(nullable = false)
    private String ClastName;

    @Column(nullable = false)
    private String Caddress;

    @Column(nullable = false)
    private String Cphone;

    @Column(nullable = false)
    private String Cemail;

    protected Client() {

    }

    public Client(String CfirstName, String ClastName, String Caddress, String Cphone, String Cemail) 
    {
        this.CfirstName = firstName;
        this.ClastName = lastName;
        this.Caddress = address;
        this.Cphone = phone;
        this.Cemail = email;
    }

    public Long getClientId() {
        return getClientId;
    }

    public String getCFirstName() {
        return firstName;
    }

    public void setCFirstName(String CfirstName) {
        this.CfirstName = firstName;
    }

    public String getCLastName() {
        return lastName;
    }

    public void setCLastName(String ClastName) {
        this.ClastName = lastName;
    }

    public String getCAddress() {
        return address;
    }

    public void setCAddress(String Caddress) {
        this.Caddress = address;
    }

    public String getCPhone() {
        return Cphone;
    }

    public void setCPhone(String Cphone) {
        this.Cphone = phone;
    }

    public String getCEmail() {
        return Cemail;
    }

    public void setCEmail(String Cemail) {
        this.Cemail = email;
    }
}
